-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 10, 2024 at 07:29 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `advanced_programming_and_technologies_course_work`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `email` varchar(255) NOT NULL,
  `ProductID` varchar(255) NOT NULL,
  `CartID` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`email`, `ProductID`, `CartID`) VALUES
('admin@admin.com', '1', 11),
('nabinKhakurel@gmail.com', '1', 17),
('nabinKhakurel@gmail.com', '1', 18),
('admin@admin.com', '11', 25),
('nabinKhakurel@gmail.com', '11', 34);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `paymentmethod` varchar(255) NOT NULL,
  `cardno` varchar(255) NOT NULL,
  `expirationdate` varchar(255) NOT NULL,
  `userid` varchar(255) NOT NULL,
  `cvcno` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `ProductID` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Price` varchar(255) NOT NULL,
  `Rating` varchar(255) NOT NULL,
  `Brand` varchar(255) NOT NULL,
  `ProductPhoto` varchar(255) NOT NULL,
  `Stock` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`ProductID`, `Name`, `Price`, `Rating`, `Brand`, `ProductPhoto`, `Stock`) VALUES
(14, 'JBL Authentics 300', '2000', '3.0', 'JBL', 'JBL Authentics 300.png', '20'),
(19, 'JBL Authentics 500', '1299', '2.0', 'JBL', 'JBL Authentics 500.png', '10'),
(20, 'JBL clip 4', '899', '3.0', 'JBL', 'JBL clip 4.png', '10'),
(23, 'JBL Boombox 3', '2500', '5.0', 'JBL', 'JBL Boombox 3.png', '8'),
(24, 'JBL Partybox 110', '3000.0', '4.0', 'JBL', 'JBL Partybox 110.png', '12'),
(26, 'JBL Partybox Encore Essential', '1999', '3.0', 'JBL', 'JBL Partybox Encore Essential.png', '10'),
(27, 'Stone Ignite', '2300', '4.0', 'boAT', 'Screenshot 2024-05-09 114930.png', '10'),
(28, 'Stone 1500', '2700', '4', 'boAT', 'Screenshot 2024-05-09 114654.png', '10');

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `CartID` varchar(255) NOT NULL,
  `Quantity` varchar(255) NOT NULL,
  `PurchaseID` int(11) NOT NULL,
  `Purchase_Date` timestamp NOT NULL DEFAULT current_timestamp(),
  `useremail` varchar(255) NOT NULL,
  `ProductID` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`CartID`, `Quantity`, `PurchaseID`, `Purchase_Date`, `useremail`, `ProductID`) VALUES
('7', '1', 1, '2024-04-26 02:25:48', '', 0),
('1', '1', 2, '2024-04-26 02:25:48', '', 0),
('1', '1', 3, '2024-04-26 02:25:48', '', 0),
('8', '1', 4, '2024-04-26 02:25:48', '', 0),
('9', '1', 5, '2024-04-26 02:25:48', '', 0),
('7', '1', 6, '2024-04-26 02:28:02', '', 0),
('7', '1', 7, '2024-04-26 02:33:15', '', 0),
('10', '1', 8, '2024-04-26 02:34:49', '', 0),
('10', '1', 9, '2024-04-26 02:37:08', '', 0),
('10', '1', 10, '2024-04-26 02:38:30', '', 0),
('15', '1', 11, '2024-04-26 02:42:12', '', 0),
('16', '1', 12, '2024-04-26 02:44:04', '', 0),
('24', '1', 13, '2024-04-26 11:33:55', '', 0),
('26', '1', 14, '2024-04-28 12:35:40', '', 0),
('27', '1', 15, '2024-04-28 12:51:44', '', 0),
('28', '1', 16, '2024-04-28 15:33:44', 'nabinKhakurel@gmail.com', 0),
('29', '1', 17, '2024-04-29 10:50:15', 'nabinKhakurel@gmail.com', 12),
('30', '1', 18, '2024-04-29 10:52:00', 'nabinKhakurel@gmail.com', 11),
('31', '1', 19, '2024-04-29 10:52:01', 'nabinKhakurel@gmail.com', 11),
('33', '1', 20, '2024-04-29 12:47:18', 'nabinKhakurel@gmail.com', 10),
('35', '1', 21, '2024-05-08 12:49:23', 'jerry@gmail.com', 12),
('39', '1', 22, '2024-05-08 15:34:56', 'jpt@gmail.com', 19),
('41', '1', 23, '2024-05-09 05:03:16', 'jpt@gmail.com', 14);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `username`, `password`) VALUES
(1, 'admin@admin.com', 'sunita', 'EgmD6EhnCXMSCp2tifgx7g=='),
(2, 'nabinKhakurel@gmail.com', 'Nabin', 'EgmD6EhnCXMSCp2tifgx7g=='),
(3, 'jerry@gmail.com', 'aayush', 'kSbq+35e8AkCs/g77mvH7Q=='),
(4, 'jpt@gmail.com', 'jpt', 'yJBxuh3h5LKKMqaOJ0nj/g==');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`CartID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`ProductID`);

--
-- Indexes for table `purchase`
--
ALTER TABLE `purchase`
  ADD PRIMARY KEY (`PurchaseID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `CartID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `ProductID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `purchase`
--
ALTER TABLE `purchase`
  MODIFY `PurchaseID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
