package controller.attributes;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.DAO.DeleteDAO;
import model.DAO.InsertDAO;

import java.io.IOException;

/**
 * Servlet implementation class AddCart
 */

public class PurchaseProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String cartid = request.getParameter("cartid");
		String quantity = request.getParameter("quantity");
		System.out.println("iiiiiiii"+cartid+quantity);
		System.out.println(request.getParameter("useremail"));
		String email=request.getParameter("useremail");
		String productID=request.getParameter("productid");
		System.out.println("id is"+productID);
		InsertDAO udao = new InsertDAO();
		String message = udao.addPurchase(cartid, quantity,email,productID);
		DeleteDAO udao1 = new DeleteDAO();
		String message1 = udao1.removeCart(cartid);
		if(message == "Successfully Added"){
			response.sendRedirect("addtocart.jsp");
		}
	}

}
